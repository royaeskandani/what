#ifndef PROJECT_H
#define PROJECT_H

int project(void);

#endif
